package com.example.review;

public class Comments {
    
    public static void mail(String args[]){
     
        // Single Line Comment
        
        /* Multi 
         * Line
         * Comment
         */
        
        /** Documentation
         * comment
         */
        
    }
    
}
