package com.example.review;

public class Simple{

    public static void main(String args[]){
        
    }
}
