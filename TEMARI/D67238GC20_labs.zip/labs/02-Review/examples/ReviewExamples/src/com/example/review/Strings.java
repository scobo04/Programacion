package com.example.review;

public class Strings {

    public static void main(String args[]){
        
        char letter = 'a';
        
        String string1 = "Hello";
        String string2 = "World";
        String string3 = "";
        
        string3 = string1 + string2; // Concatenate strings

        System.out.println("Output: " + string3 + " " + letter);
        
    }
    
}
