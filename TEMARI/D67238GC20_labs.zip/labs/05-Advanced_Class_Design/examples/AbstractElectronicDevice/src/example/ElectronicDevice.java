package example;

public abstract class ElectronicDevice {
    
    public abstract void turnOn();
    
    public abstract void turnOff();
    
}
