package com.example;

public enum PowerState {

    OFF,
    ON,
    SUSPEND;
}