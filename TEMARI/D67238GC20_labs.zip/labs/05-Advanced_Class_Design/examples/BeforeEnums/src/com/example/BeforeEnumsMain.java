package com.example;

public class BeforeEnumsMain {

    public static void main(String[] args) {
        Computer comp = new Computer();
        comp.setState(Computer.POWER_SUSPEND);
    }
}