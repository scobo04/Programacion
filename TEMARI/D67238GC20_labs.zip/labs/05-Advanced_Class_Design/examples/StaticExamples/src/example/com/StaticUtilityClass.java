package example.com;

public class StaticUtilityClass {
    
    public static void printMessage() {
        System.out.println("no need for objects here");
    }
    
}