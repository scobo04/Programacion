package com.example;

public class BasicCar implements Car {
    
    public void start() {
        System.out.println("Starting car...");
    }

}