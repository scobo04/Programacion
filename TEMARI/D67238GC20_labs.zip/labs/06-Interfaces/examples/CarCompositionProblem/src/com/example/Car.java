package com.example;

public interface Car {
    public void start();
}
