package com.example;

public class CarWithSunRoof extends BasicCar {
    
    public void openSunRoof() {
        
    }
    
    public void closeSunRoof() {
        
    }
    
}
