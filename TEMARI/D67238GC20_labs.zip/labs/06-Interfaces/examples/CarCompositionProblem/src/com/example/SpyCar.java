package com.example;

public class SpyCar extends BasicCar {
    
    public void shootRockets() {
        
    }
    
}
