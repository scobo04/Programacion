package com.example;

public class SunRoofAddon {
    
    public void openSunRoof() {
        
    }
    
    public void closeSunRoof() {
        
    }
    
}
