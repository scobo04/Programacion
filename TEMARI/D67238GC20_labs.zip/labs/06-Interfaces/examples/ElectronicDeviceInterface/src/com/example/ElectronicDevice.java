package com.example;

public interface ElectronicDevice {
    public static final String WARNING = "Do not open, shock hazard";
    public void turnOn();
    public void turnOff();   
}