
package com.example;

public interface Boat {
    
    public void launch();
    
}