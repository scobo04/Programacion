package com.example;

public interface MotorizedBoat extends Boat {
    
    public void start();
    
}
