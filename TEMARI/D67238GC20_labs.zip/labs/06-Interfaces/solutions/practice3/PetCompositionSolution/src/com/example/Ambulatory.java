package com.example;

public interface Ambulatory {
    
    public void walk();
    
}