package com.example;

public abstract class Animal {
       
    public abstract void eat();
    
}