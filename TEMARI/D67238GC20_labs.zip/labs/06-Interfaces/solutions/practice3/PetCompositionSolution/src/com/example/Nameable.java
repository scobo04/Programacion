package com.example;

public interface Nameable {
    
    public void setName(String name);
    
    public String getName();
    
}