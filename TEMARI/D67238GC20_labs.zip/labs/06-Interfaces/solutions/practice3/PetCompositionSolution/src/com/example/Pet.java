package com.example;

interface Pet extends Nameable {

    public void play();
    
}