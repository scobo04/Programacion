package com.example.collections;

public enum Grade {
    F, D, C, B, A;
}
